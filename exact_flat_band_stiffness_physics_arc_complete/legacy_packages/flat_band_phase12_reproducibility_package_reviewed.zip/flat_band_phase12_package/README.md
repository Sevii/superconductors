# Resonant-winding flat-band counterexample: Phase I/II package

This package accompanies the revised research note **Zero-Twist Uniform Pairing Does Not Fix Finite-Torus Twist Curvature** by **Nicholas Sledgianowski**. OpenAI's ChatGPT Sol 5.6 provided computational and drafting assistance under the author's direction.

## Scientific scope

The package certifies a limitation of a zero-twist-UPC exact finite-torus filling law. It does **not** claim to refute the fixed-local thermodynamic QGN conjecture. The decisive mechanism is a period-`M` winding resonance under a displacement-resolved `k -> k+A` twist prescription.

## Contents

- `flat_band_counterexample_exact.py` - exact SymPy Kohn-response certificate for the unique, gapped `M=4` example.
- `flat_band_resonance_phase12.py` - independent fixed-number NumPy/SciPy implementation for the `M=4, r=4`, `M=8, r=4`, and `M=8, r=8` comparisons.
- `phase2_formula_certificate.py` - symbolic certificate for the arbitrary-`M` period-`M` curvature and defect formulas.
- `tests/test_phase12.py` - regression tests for the exact curvatures, operator factorization, the nonresonant control, the restored resonance, the positive-semidefinite convention, and twist-stable UPC.
- `phase12_results_cross.csv` and `phase12_results_psd.csv` - archived default-run reference output.
- `resonance_comparison_data.csv` - all plotted reduced-curvature points, including the M=8, n=3 controls, with analytic source formulas.
- `resonance_comparison.png` - reduced-curvature comparison figure.
- `manuscript_source.md` - source text for the revised research note.
- `requirements.txt` - compatible package ranges.
- `requirements-lock.txt` - exact package versions used for the archived verification run.

## Environment

Python 3.11 or newer is recommended.

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

For exact archived versions instead:

```bash
python -m pip install -r requirements-lock.txt
```

## Reproduce the exact four-cell result

```bash
python flat_band_counterexample_exact.py
```

Expected exact headline outputs:

- raw two-pair defect: `2/3`
- normalized defect: `1/24`
- `K_3-K_1 = 1/8`

## Verify the arbitrary-M Phase II formula

```bash
python phase2_formula_certificate.py
```

The certificate returns

```text
f''(0) = -8*M**2*c**2*q**2
extra E_n'' = 4*M**2*U*c**2*n*q**2
raw defect = 4*M**2*U*c**2*n*q**2*(n - 1)/(M - 1)
normalized defect = M*U*c**2*n*q**2*(n - 1)/(M - 1)
```

## Run the Phase I/II comparisons

```bash
python flat_band_resonance_phase12.py --csv phase12_results_cross_new.csv
python flat_band_resonance_phase12.py --convention psd --csv phase12_results_psd_new.csv
```

The default suite checks:

1. `M=4, r=4`: scalar period-`M` resonance and filling-law violation;
2. `M=8, r=4`: the same hidden harmonic, no scalar factorization, and the filling law restored numerically;
3. `M=8, r=8`: scalar resonance restored, with raw two-pair defect `8/7`.

Use `--full` to include the `n=3` sectors at `M=8`; this is substantially slower. The lightweight `resonance_comparison_data.csv` archives every point used in the figure, including the analytically controlled n=3 values independently reproduced during review.

## Run regression tests

```bash
pytest -q
```

The archived suite contains eight tests and should report `8 passed`.

## Interaction conventions

The numerical script supports two projected interactions:

- `cross`: `-U sum nbar_up nbar_down`
- `psd`: `(U/2) sum (nbar_up-nbar_down)^2`

The twist is inserted before projection through `k -> k+A` using the supplied displacement-resolved Bloch lift.

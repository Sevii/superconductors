#!/usr/bin/env python3
"""Symbolic certificate for the arbitrary-M period-M resonance formulas."""

from __future__ import annotations

import sympy as sp


def main() -> None:
    A = sp.symbols("A", real=True)
    M, q, c, U = sp.symbols("M q c U", positive=True)
    n = sp.symbols("n", integer=True, positive=True)

    f = sp.cos(2 * c * sp.sin(q * M * A)) ** 2
    f_second = sp.simplify(sp.diff(f, A, 2).subs(A, 0))
    assert sp.simplify(f_second + 8 * c**2 * q**2 * M**2) == 0

    energy_zero = -U * n / 2
    extra_curvature = sp.simplify(f_second * energy_zero)
    assert sp.simplify(extra_curvature - 4 * U * c**2 * q**2 * M**2 * n) == 0

    rho = n * (M - n) / (M - 1)
    one_pair_extra = extra_curvature.subs(n, 1)
    raw_defect = sp.factor(extra_curvature - rho * one_pair_extra)
    expected_raw = 4 * U * c**2 * q**2 * M**2 * n * (n - 1) / (M - 1)
    assert sp.simplify(raw_defect - expected_raw) == 0

    normalized_defect = sp.factor(raw_defect / (4 * M))
    expected_normalized = U * c**2 * q**2 * M * n * (n - 1) / (M - 1)
    assert sp.simplify(normalized_defect - expected_normalized) == 0

    print("f''(0) =", f_second)
    print("extra E_n'' =", extra_curvature)
    print("raw filling-law defect =", raw_defect)
    print("normalized K defect =", normalized_defect)
    print()
    print("M=4, q=1, c=1/8, n=2:")
    substitutions = {M: 4, q: 1, c: sp.Rational(1, 8), n: 2}
    print("  raw defect =", sp.simplify(raw_defect.subs(substitutions)))
    print("  normalized defect =", sp.simplify(normalized_defect.subs(substitutions)))
    print()
    print("M=8, q=1, c=1/8, n=2:")
    substitutions = {M: 8, q: 1, c: sp.Rational(1, 8), n: 2}
    print("  raw defect =", sp.simplify(raw_defect.subs(substitutions)))


if __name__ == "__main__":
    main()

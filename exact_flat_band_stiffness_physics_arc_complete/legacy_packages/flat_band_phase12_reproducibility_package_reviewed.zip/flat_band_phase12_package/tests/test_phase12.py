"""Regression tests for the finite-torus resonant-winding examples."""

from __future__ import annotations

import math
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from flat_band_resonance_phase12 import (  # noqa: E402
    energy_curvature,
    factorization_diagnostic,
    filling_multiplier,
)

B = math.pi / 2.0
U = 1.0
C = 1.0 / 8.0
STEP = 7.0e-4


def curvature(M: int, n: int, harmonic: int, convention: str = "cross") -> tuple[float, float, float]:
    return energy_curvature(M, n, C, harmonic, B, U, convention, STEP)


def test_m4_exact_spectrum_and_curvatures() -> None:
    expected = {
        1: math.pi**2 / 8.0 + 1.0,
        2: math.pi**2 / 6.0 + 2.0,
        3: math.pi**2 / 8.0 + 3.0,
    }
    for n in (1, 2, 3):
        energy, gap, second = curvature(4, n, 4)
        assert abs(energy + n / 2.0) < 1.0e-12
        assert abs(gap - 0.25) < 1.0e-12
        assert abs(second - expected[n]) < 2.0e-7


def test_m4_operator_factorization() -> None:
    scalar, max_error, relative_error = factorization_diagnostic(
        4, 2, C, 4, 0.137, B, U, "cross"
    )
    expected_scalar = math.cos(2.0 * C * math.sin(4.0 * 0.137)) ** 2
    assert abs(scalar - expected_scalar) < 1.0e-14
    assert max_error < 5.0e-14
    assert relative_error < 5.0e-14


def test_m8_r4_nonresonant_control_obeys_filling_law() -> None:
    _, _, e1pp = curvature(8, 1, 4)
    _, _, e2pp = curvature(8, 2, 4)
    defect = e2pp - filling_multiplier(8, 2) * e1pp
    assert abs(defect) < 2.0e-7

    _, max_error, relative_error = factorization_diagnostic(
        8, 2, C, 4, 0.137, B, U, "cross"
    )
    assert max_error > 1.0e-3
    assert relative_error > 1.0e-2


def test_m8_r8_resonance_has_predicted_defect() -> None:
    _, _, e1pp = curvature(8, 1, 8)
    _, _, e2pp = curvature(8, 2, 8)
    defect = e2pp - filling_multiplier(8, 2) * e1pp
    assert abs(defect - 8.0 / 7.0) < 2.0e-7

    _, max_error, relative_error = factorization_diagnostic(
        8, 2, C, 8, 0.137, B, U, "cross"
    )
    assert max_error < 5.0e-14
    assert relative_error < 5.0e-14


def test_psd_convention_retains_m4_violation() -> None:
    _, _, e1pp = curvature(4, 1, 4, "psd")
    _, _, e2pp = curvature(4, 2, 4, "psd")
    defect = e2pp - filling_multiplier(4, 2) * e1pp
    assert abs(defect - 4.0 / 3.0) < 3.0e-7



def test_psd_m4_recognized_exact_curvatures() -> None:
    expected = {
        1: math.pi**2 / 8.0 + 2.0,
        2: math.pi**2 / 6.0 + 4.0,
        3: math.pi**2 / 8.0 + 6.0,
    }
    for n in (1, 2, 3):
        _, _, second = curvature(4, n, 4, "psd")
        assert abs(second - expected[n]) < 4.0e-7

def test_twist_stable_upc_control_identity() -> None:
    # For M=8, r=4, half the sampled points carry +x and half -x,
    # so the finite-grid orbital-weight average is exactly 1/2.
    A = 0.137
    k = 2.0 * np.pi * np.arange(8) / 8
    theta = np.pi / 4.0 + C * np.sin(4.0 * (k + A))
    average = float(np.mean(np.cos(theta) ** 2))
    assert abs(average - 0.5) < 1.0e-14

    # In the period-8 resonance, all points carry the same deformation,
    # so the average departs from 1/2.
    theta_res = np.pi / 4.0 + C * np.sin(8.0 * (k + A))
    average_res = float(np.mean(np.cos(theta_res) ** 2))
    assert abs(average_res - 0.5) > 1.0e-3


def test_arbitrary_m_degenerate_obstruction_formula() -> None:
    # phi=0 (b=0) gives an exact degenerate ground manifold and a base
    # Hamiltonian with zero twist curvature.  Check the general defect at M=5.
    M = 5
    _, _, e1pp = energy_curvature(M, 1, C, M, 0.0, U, "cross", STEP)
    _, _, e2pp = energy_curvature(M, 2, C, M, 0.0, U, "cross", STEP)
    defect = e2pp - filling_multiplier(M, 2) * e1pp
    expected = 4.0 * U * C * C * M * M * 2.0 / (M - 1)
    assert abs(defect - expected) < 3.0e-7

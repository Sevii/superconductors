from __future__ import annotations
import sys,time,json
from pathlib import Path
import numpy as np
sys.path.insert(0,'/mnt/data')
import qgn_search_v3 as q

rng=np.random.default_rng(20260723)
base=q.standard_channels(); names=('P0','P1','I','sx','sy','sz','bI1c','bI1s','bsx1c','bsx1s','bsz1c','bI2c')
pool=[base[k] for k in names]
projectors=[
 ('A',q.model_flattened_1d,{'a':0.3,'m':1.4,'bz':0.5,'bx':0.8,'by':0.7,'cx':0.12,'cy':-0.08,'cz':0.11}),
 ('B',q.model_flattened_1d,{'a':-0.2,'m':0.85,'bz':0.6,'bx':1.0,'by':0.9,'cx':0.25,'cy':0.18,'cz':-0.2}),
 ('C',q.model_flattened_1d,{'a':0.65,'m':1.25,'bz':-0.35,'bx':0.5,'by':1.1,'cx':-0.3,'cy':0.22,'cz':0.15}),
 ('phase',q.model_phase_1d,{'xi':1.7,'zeta':0.35}),
]
N=1200
recs=[]; t=time.time()
for trial in range(N):
    pname,model,params=projectors[trial%len(projectors)]
    # one random linear-combination square, plus independently weighted second square on half trials
    coeff1=rng.normal(size=len(pool)); coeff1/=np.linalg.norm(coeff1)
    channels=[q.combine_channels(pool,coeff1,f't{trial}a')]
    coeff2=None
    if trial%3==1:
        coeff2=rng.normal(size=len(pool)); coeff2/=np.linalg.norm(coeff2)
        ch2=q.combine_channels(pool,coeff2,f't{trial}b')
        channels.append(q.HermitianChannel(ch2.name,ch2.components,float(10**rng.uniform(-1.5,0.3))))
    try:
        rows=q.evaluate_case('x',6,model,params,channels,[1,3],h=0.003)
    except Exception as e:
        continue
    r=rows[1]
    rec={'trial':trial,'projector':pname,'params':params,'coeff1':coeff1.tolist(),'coeff2':None if coeff2 is None else coeff2.tolist(),'weight2':None if coeff2 is None else channels[1].weight,'ratio6':r['ratio'],'dev6':r['ratio']-1,'gap1':rows[0]['gap'],'gap3':r['gap'],'deg1':rows[0]['deg'],'deg3':r['deg'],'c1':rows[0]['curvature']}
    if r['deg']==1 and rows[0]['deg']==1 and np.isfinite(r['ratio']): recs.append(rec)
    if trial%100==0: print(trial,'best',max((abs(x['dev6']) for x in recs),default=0),'elapsed',time.time()-t,flush=True)

recs.sort(key=lambda x:abs(x['dev6']),reverse=True)
Path('/mnt/data/search_connected_candidates_m6.json').write_text(json.dumps(recs[:100],indent=2))
print('M6 done',len(recs),'top',[(x['trial'],x['projector'],x['dev6'],x['gap3']) for x in recs[:20]],'elapsed',time.time()-t)

# evaluate top 35 at M=8 and top 10 at M=10 n=2 and optionally half filling only if affordable later
for rec in recs[:35]:
    pname,model,params=next(x for x in projectors if x[0]==rec['projector'])
    c1=np.array(rec['coeff1']); channels=[q.combine_channels(pool,c1,'a')]
    if rec['coeff2'] is not None:
        c2=np.array(rec['coeff2']); ch2=q.combine_channels(pool,c2,'b'); channels.append(q.HermitianChannel(ch2.name,ch2.components,rec['weight2']))
    rows=q.evaluate_case('x',8,model,params,channels,[1,4],h=0.003)
    rec['ratio8']=rows[1]['ratio']; rec['dev8']=rows[1]['ratio']-1; rec['gap8']=rows[1]['gap']; rec['deg8']=rows[1]['deg']; rec['c1_8']=rows[0]['curvature']
    print('M8',rec['trial'],rec['projector'],'dev6',rec['dev6'],'dev8',rec['dev8'],'gap8',rec['gap8'],flush=True)
Path('/mnt/data/search_connected_candidates_top_m8.json').write_text(json.dumps(recs[:35],indent=2))
print('all elapsed',time.time()-t)
